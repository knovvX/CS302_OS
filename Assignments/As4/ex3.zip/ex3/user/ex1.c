#include <ulib.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int
main(void) {
    // //open this!
    // cprintf("\n-------ex1---start------\n");
    // set_priority(5);
    // cprintf("-------ex1----end-------\n\n");
}

